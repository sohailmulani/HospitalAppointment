package com.hms.service;

import java.util.List;
import java.util.Optional;

import org.hibernate.annotations.HQLSelect;
import org.hibernate.annotations.SelectBeforeUpdate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hms.dao.AppointmentDao;
import com.hms.dao.DepartmentDao;
import com.hms.dao.HmsDao;
import com.hms.dao.HmsPatientDao;
import com.hms.dao.LoginDao;
import com.hms.dao.ProfileDao;
import com.hms.model.AppointmentModel;
import com.hms.model.DepartmentModel;
import com.hms.model.HmsModel;
import com.hms.model.HmsPatientsModel;
import com.hms.model.Login;
import com.hms.model.ProfileModel;

@Service
public class HmsService {
	@Autowired
	HmsDao ad;
	
	@Autowired
	HmsPatientDao hpd;
	
	@Autowired
	LoginDao ld;
	
	@Autowired
	DepartmentDao dd;
	
	@Autowired
	ProfileDao pd;
	
	@Autowired
	AppointmentDao a;
	
	
	
	//for admin login
	public Login findByUserId(String userID, String password) {
		return ld.getReferenceById(userID);
	}
	
	// for patient login
	
	public HmsPatientsModel findBypatientId(String PEmail, String password, Integer patientId) {
		return hpd.getReferenceById(patientId);
	}
	
//	doctor's functionality starts from here
	
	//get all doctors
	public List getAllDoctors() {
		return ad.findAll();
	}
	
	//add doctor
	public HmsModel addDoctor(HmsModel hm) {
		return ad.save(hm);
	}
	
	//get doctor by id
	public HmsModel getDoctorById(int doctorID) {
		return ad.findById(doctorID).get();
	}
	
	//delete doctor
	public void deleteDoctor(int doctorID) {
		ad.deleteById(doctorID);
	}
	
	//update doctor
	public HmsModel updateDoctor(HmsModel hm, int doctorID) {
		HmsModel hmsModel1 = ad.findById(doctorID).get();
		hmsModel1.setFirstName(hm.getFirstName());
		hmsModel1.setLastName(hm.getLastName());
		hmsModel1.setSpecialist(hm.getSpecialist());
		hmsModel1.setDegree(hm.getDegree());
		hmsModel1.setmobileNumber(hm.getMobileNumber());
		hmsModel1.setEmail(hm.getEmail());
		hmsModel1.setGender(hm.getGender());
		return ad.save(hmsModel1);
	}
	
	
	
//	doctor's functionality ends here
	
//	department's functionality starts from here
	
	//add department
	public DepartmentModel addDepartment(DepartmentModel dm) {
		return dd.save(dm);
	}
	
	//get all departments
	public List getAllDepartments() {
		return dd.findAll();
	}	
	
	//get department by id
	public DepartmentModel getDepartmentById(int departmentID) {
		return dd.findById(departmentID).get();
	}
	
	//delete department
	public void deleteDepartment(int departmentID) {
		dd.deleteById(departmentID);
	}
	
	//update department
	
	public DepartmentModel updateDepartent(DepartmentModel dm, int departmentID) {
		DepartmentModel dm1 = dd.findById(departmentID).get();
		dm1.setDepartmentName(dm.getDepartmentName());
		return dd.save(dm1);
	}
	
//	departments's functionality ends here
	
// patinet's functionality starts from here
	
	//add patient
	public HmsPatientsModel addPatient(HmsPatientsModel pm) {
		return hpd.save(pm);
	}
	
	//get all patients
	public List<HmsPatientsModel> getAllPatients() {
		return (List<HmsPatientsModel>)hpd.findAll();
	}
	
	//get patient by id
	public HmsPatientsModel getPatinetById(int patientId) {
		return hpd.findById(patientId).get();
	}
	
	//delete patient
	public void deletePatient(int patientId) {
		hpd.deleteById(patientId);
	}
	
	//update patient
	public HmsPatientsModel updatePatient(HmsPatientsModel hpm, int patientId) {
		HmsPatientsModel hpm1 = hpd.findById(patientId).get();
		hpm1.setPFName(hpm.getPFName());
		hpm1.setPLName(hpm.getPLName());
		hpm1.setPEmail(hpm.getPEmail());
		hpm1.setPMobileNumber(hpm.getPMobileNumber());
		hpm1.setPGender(hpm.getPGender());
		hpm1.setPAge(hpm.getPAge());
		hpm1.setDecease(hpm.getDecease());
		hpm1.setPAddr(hpm.getPAddr());
		hpm1.setPDOB(hpm.getPDOB());
		return hpd.save(hpm1);
	}

// patient's functionality ends here	
	
	
// profile's functionality starts
	
	//get profile
	
	public List<ProfileModel> getAllProfiles() {
		return (List<ProfileModel>)pd.findAll();
	}
	
	//get profile by id
	public ProfileModel getProfileById(int profileId) {
		return pd.findById(profileId).get();
	}
	
	//update profile
	public ProfileModel updateProfile(ProfileModel pm, int profileId) {
		ProfileModel pm1 = pd.findById(profileId).get();
		pm1.setFullName(pm.getFullName());
		pm1.setAdminEmail(pm.getAdminEmail());
		pm1.setPhoneNumber(pm.getPhoneNumber());
		return pd.save(pm1);
	}
// profile's functionality ends	
	
// appointment
	
	//take appointment
	public AppointmentModel takeAppointment(AppointmentModel am) {
		return a.save(am);
	}
	
	//get all appointments
	public List<AppointmentModel> getAllAppointments() {
		return (List<AppointmentModel>)a.findAll();
	}
	
	//get appointment by id
	public AppointmentModel getAppointmentById(int appointmentId) {
		return a.findById(appointmentId).get();
	}
	
	//update appointment
	public AppointmentModel updateAppointment(AppointmentModel am, int appointmentId) {
		AppointmentModel a1 = a.findById(appointmentId).get();
		a1.setPatientName(am.getPatientName());
		a1.setPatientNumber(am.getPatientNumber());
		a1.setAppointmentDate(am.getAppointmentDate());
		a1.setMessage(am.getMessage());
		return a.save(a1);
	}
	
	//cancel appointment
	public void cancelAppointment(int appointmentId) {
		a.deleteById(appointmentId);
	}

	
}
