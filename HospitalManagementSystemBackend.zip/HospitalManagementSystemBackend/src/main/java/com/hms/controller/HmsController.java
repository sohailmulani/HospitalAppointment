package com.hms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hms.dao.LoginDao;
import com.hms.model.AppointmentModel;
import com.hms.model.DepartmentModel;
import com.hms.model.HmsModel;
import com.hms.model.HmsPatientsModel;
import com.hms.model.Login;
import com.hms.model.ProfileModel;
import com.hms.service.HmsService;

@CrossOrigin(origins ="http://localhost:4200")
@RestController
public class HmsController {
	
	@Autowired
	HmsService hs;
	

	//admin login
	@PostMapping("/login")
	public void loginUser(@RequestBody Login loginData){
		System.out.println(loginData);
		Login login = hs.findByUserId(loginData.getUserID(), loginData.getPassword());
		if(login.getPassword().equals(loginData.getPassword())) {
			System.out.println("success");
		}else {
			System.out.println("not success");
		}			
	}
	
	
	// patient login
	@PostMapping("/loginp")
	public void patientLogin(@RequestBody HmsPatientsModel data) {
		System.out.println(data);
		HmsPatientsModel hpm1 = hs.findBypatientId(data.getPEmail(), data.getPassword(), data.getPatientId());
		if(data.getPassword().equals(data.getPassword())) {
			System.out.println("login siccess");
		}else {
			System.out.println("login failed");
		}
		
	}
	
// doctor's functionality starts from here
	
	//read all doctors
	@GetMapping("view-doctors")	
	public List<HmsModel> getAllDoctors(){
		return this.hs.getAllDoctors();
	}
	
	//add doctor
	@PostMapping("add-doctors")
	public HmsModel addDoctor(@RequestBody HmsModel hm) {
		HmsModel hmsModel1 = hs.addDoctor(hm);
		return hmsModel1;
	}
	
	//delete doctor
	@DeleteMapping("/delete-doctors/{doctorID}")
	public void deleteDoctor(@PathVariable("doctorID") int doctorID) {
		hs.deleteDoctor(doctorID);
	}
	
	//update all doctors
	@PutMapping("/update-doctor/{doctorID}")
	public HmsModel updateDoctor(@RequestBody HmsModel hm, @PathVariable("doctorID") int doctorID) {
		return hs.updateDoctor(hm, doctorID);
	}
	
	//get doctor by ID
	@GetMapping("/doctor/{doctorID}")
	public HmsModel getDoctorById(@PathVariable("doctorID") int doctorID) {
		return hs.getDoctorById(doctorID);
	}
	

// 	doctor's functionality ends here
	
// department's functionality starts from here
	
	// read all department
	@GetMapping("view-department")	
	public List<DepartmentModel> getAllDepartments(){
		return this.hs.getAllDepartments();
	}
	
	// add department
	@PostMapping("add-department")
	public DepartmentModel addDepartment(@RequestBody DepartmentModel dm) {
		DepartmentModel dm1 = hs.addDepartment(dm);
		return dm1;
	}
	
	// delete department
	@DeleteMapping("/delete-department/{departmentID}")
	public void deleteDepartment(@PathVariable("departmentID") int departmentID) {
		hs.deleteDepartment(departmentID);
	}
	
	// update department
	@PutMapping("/update-department/{departmentID}")
	public DepartmentModel updateDepartent(@RequestBody DepartmentModel dm, @PathVariable("departmentID") int departmentID) {
		return hs.updateDepartent(dm, departmentID);
	}
	
	// get department by id
	@GetMapping("/department/{departmentID}")
	public DepartmentModel getDepartmentById(@PathVariable("departmentID") int departmentID) {
		return hs.getDepartmentById(departmentID);
	}
	
// departmet's functionality ends here	
	
// patient's functionality starts here
	
	// read all patients
	@GetMapping("/view-patients")	
	public List<HmsPatientsModel> getAllPatients(){
		return this.hs.getAllPatients();
	}
	
	// add patient
	@PostMapping("/add-patients")
	public HmsPatientsModel addPatient(@RequestBody HmsPatientsModel hpm) {
		HmsPatientsModel hpm1 = hs.addPatient(hpm);
		return hpm1;
	}
	
	// delete patient
	@DeleteMapping("/delete-patient/{patientId}")
	public void deletePatient(@PathVariable("patientId") int patientId) {
		hs.deletePatient(patientId);
	}
	
	// update patient
	@PutMapping("/update-patient/{patientId}")
	public HmsPatientsModel updatePatient(@RequestBody HmsPatientsModel hpm, @PathVariable("patientId") int patientId) {
		return hs.updatePatient(hpm, patientId);
	}
	
	// get patient by id
	@GetMapping("/patient/{patientId}")
	public HmsPatientsModel getPatinetById(@PathVariable("patientId") int patientId) {
		return hs.getPatinetById(patientId);
	}
	
// profile functionality starts
	
	//get profile
	@GetMapping("/admin-profile")	
	public List<ProfileModel> getAllProfiles(){
		return this.hs.getAllProfiles();
	}
	
	
	// get profile by id
	@GetMapping("/profile/{profileId}")
	public ProfileModel getProfileById(@PathVariable("profileId") int profileId) {
		return hs.getProfileById(profileId);
	}
	
	//update profile
	@PutMapping("/update-admin-profile/{profileId}")
	public ProfileModel updateProfile(@RequestBody ProfileModel pm, @PathVariable("profileId") int profileId) {
		return hs.updateProfile(pm, profileId);
	}
	
	
// appointment module
	
	//get appointment
	@PostMapping("/take-appointment")
	public AppointmentModel takeAppointment(@RequestBody AppointmentModel am) {
		AppointmentModel am1 = hs.takeAppointment(am);
		return am1;
	}
	
	//get appointment by id
	@GetMapping("/appointment/{appointmentId}")
	public AppointmentModel getAppointmentById(@PathVariable("appointmentId") int appointmentId) {
		return hs.getAppointmentById(appointmentId);
	}
	
	//get all appointments
	@GetMapping("/view-appointments")	
	public List<AppointmentModel> getAllAppointments(){
		return this.hs.getAllAppointments();
	}
	
	//update appointment
	@PutMapping("/update-appointment/{appointmentId}")
	public AppointmentModel updateAppointment(@RequestBody AppointmentModel am, @PathVariable("appointmentId") int appointmentId) {
		return hs.updateAppointment(am, appointmentId);
	}
	
	//cancel appointment
	@DeleteMapping("/cancel-appointment/{appointmentId}")
	public void cancelAppointment(@PathVariable("appointmentId") int appointmentId) {
		hs.cancelAppointment(appointmentId);
	}
}


