package com.hms.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hms.model.HmsPatientsModel;

public interface HmsPatientDao extends JpaRepository<HmsPatientsModel, Integer>{

	

}
