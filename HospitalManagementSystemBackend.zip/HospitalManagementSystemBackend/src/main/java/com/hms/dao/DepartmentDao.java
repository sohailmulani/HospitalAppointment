package com.hms.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hms.model.DepartmentModel;

public interface DepartmentDao extends JpaRepository<DepartmentModel, Integer>{

}
