package com.hms.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hms.model.ProfileModel;

public interface ProfileDao extends JpaRepository<ProfileModel, Integer>{

}
