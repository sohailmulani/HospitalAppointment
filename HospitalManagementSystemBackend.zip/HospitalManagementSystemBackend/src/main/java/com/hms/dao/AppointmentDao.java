package com.hms.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hms.model.AppointmentModel;

public interface AppointmentDao extends JpaRepository<AppointmentModel, Integer>  {

}
