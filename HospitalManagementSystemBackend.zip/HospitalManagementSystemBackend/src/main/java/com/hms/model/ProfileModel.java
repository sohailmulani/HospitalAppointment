package com.hms.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class ProfileModel {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int profileId;
	String fullName;
	String adminEmail;
	long phoneNumber;
	
	public ProfileModel() {
		
	}

	public ProfileModel(int profileId, String fullName, String adminEmail, long phoneNumber) {
		
		this.profileId = profileId;
		this.fullName = fullName;
		this.adminEmail = adminEmail;
		this.phoneNumber = phoneNumber;
		
	}

	public int getProfileId() {
		return profileId;
	}

	public void setProfileId(int profileId) {
		this.profileId = profileId;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getAdminEmail() {
		return adminEmail;
	}

	public void setAdminEmail(String email) {
		this.adminEmail = email;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	@Override
	public String toString() {
		return "ProfileModel [profileId=" + profileId + ", fullName=" + fullName + ", adminEmail=" + adminEmail
				+ ", phoneNumber=" + phoneNumber + "]";
	}

	

	
	
}
