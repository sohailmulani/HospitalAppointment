package com.hms.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class AppointmentModel {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int appointmentId;
	String patientName;
	String patientNumber;
	String appointmentDate;
	String message;
	
	public AppointmentModel(int appointmentId, String patientName, String patientNumber, String appointmentDate,
			String message) {
		
		this.appointmentId = appointmentId;
		this.patientName = patientName;
		this.patientNumber = patientNumber;
		this.appointmentDate = appointmentDate;
		this.message = message;
	}

	public AppointmentModel() {
		
	}

	public int getAppointmentId() {
		return appointmentId;
	}

	public void setAppointmentId(int appointmentId) {
		this.appointmentId = appointmentId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getPatientNumber() {
		return patientNumber;
	}

	public void setPatientNumber(String patientNumber) {
		this.patientNumber = patientNumber;
	}

	public String getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(String appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "AppointmentModel [appointmentId=" + appointmentId + ", patientName=" + patientName + ", patientNumber="
				+ patientNumber + ", appointmentDate=" + appointmentDate + ", message=" + message + "]";
	}
	
	
	
}
