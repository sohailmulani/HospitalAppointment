package com.hms.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

@Entity
public class HmsPatientsModel {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int patientId;
	String PFName;
	String PLName;
	String PEmail;
	String PMobileNumber;
	String PGender;
	int PAge;
	String decease;
	String PAddr;
	String PDOB;
	String password;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "doctorName")
	private HmsModel hmsmodel;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "departmentName")
	private DepartmentModel departmentmodel;

	public HmsPatientsModel() {
		super();
	}

	public HmsPatientsModel(int patientId, String pFName, String pLName, String pEmail, String pMobileNumber,
			String pGender, int pAge, String decease, String pAddr, String pDOB, String password) {
		super();
		this.patientId = patientId;
		this.PFName = pFName;
		this.PLName = pLName;
		this.PEmail = pEmail;
		this.PMobileNumber = pMobileNumber;
		this.PGender = pGender;
		this.PAge = pAge;
		this.decease = decease;
		this.PAddr = pAddr;
		this.PDOB = pDOB;
		this.password = password;
	}

	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public String getPFName() {
		return PFName;
	}

	public void setPFName(String pFName) {
		PFName = pFName;
	}

	public String getPLName() {
		return PLName;
	}

	public void setPLName(String pLName) {
		PLName = pLName;
	}

	public String getPEmail() {
		return PEmail;
	}

	public void setPEmail(String pEmail) {
		PEmail = pEmail;
	}

	public String getPMobileNumber() {
		return PMobileNumber;
	}

	public void setPMobileNumber(String pMobileNumber) {
		PMobileNumber = pMobileNumber;
	}

	public String getPGender() {
		return PGender;
	}

	public void setPGender(String pGender) {
		PGender = pGender;
	}

	public int getPAge() {
		return PAge;
	}

	public void setPAge(int pAge) {
		PAge = pAge;
	}

	public String getDecease() {
		return decease;
	}

	public void setDecease(String decease) {
		this.decease = decease;
	}

	public String getPAddr() {
		return PAddr;
	}

	public void setPAddr(String pAddr) {
		PAddr = pAddr;
	}

	public String getPDOB() {
		return PDOB;
	}

	public void setPDOB(String pDOB) {
		PDOB = pDOB;
	}
	
	

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "HmsPatientsModel [patientId=" + patientId + ", PFName=" + PFName + ", PLName=" + PLName + ", PEmail="
				+ PEmail + ", PMobileNumber=" + PMobileNumber + ", PGender=" + PGender + ", PAge=" + PAge + ", decease="
				+ decease + ", PAddr=" + PAddr + ", PDOB=" + PDOB + ", password=" + password + ", hmsmodel=" + hmsmodel
				+ ", departmentmodel=" + departmentmodel + "]";
	}

	
	
	
		
	
	
}